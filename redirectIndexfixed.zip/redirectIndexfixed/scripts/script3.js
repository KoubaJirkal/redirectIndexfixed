const init = function(){
}

window.addEventListener("DOMContentLoaded", init)