

const init = function(){
    const ulice = document.getElementById("street")
    const email = document.getElementById("email")
    const obec = document.getElementById("municipality")
    const NUM = document.getElementById("house")
    const PSC = document.getElementById("zip")
    const password = document.getElementById("password")
    const submit = document.getElementById("submit")


    
    
    NUM.addEventListener("blur", e => {
        if (NUM.value > 999){
            console.log(NUM.value)
            NUM.classList.remove("is-invalid")
            NUM.classList.add("is-valid")
            
        }
        else{
            NUM.classList.add("is-invalid")
            NUM.classList.remove("is-valid")
        }
        
    })
    ulice.addEventListener("blur", e => {
            ulice.classList.add("is-valid")
        
    })




    PSC.addEventListener("blur", e => {
            
        if (PSC.value < 10000000000 && PSC.value > 999999999){
            console.log(PSC.value)
            PSC.classList.remove("is-invalid")
            PSC.classList.add("is-valid")
            
        }
        else{
            PSC.classList.add("is-invalid")
            PSC.classList.remove("is-valid")
        }
        
    })

    obec.addEventListener("blur", e => {
        if (obec.value == ""){
            obec.classList.add("is-invalid")
            obec.classList.remove("is-valid")
        }
        else{
            obec.classList.remove("is-invalid")
            obec.classList.add("is-valid")
            
        }
        
    })
    password.addEventListener("blur", e => {
        
        if (password.value == ""){
            password.classList.add("is-invalid")
            password.classList.remove("is-valid")
        }
        else{
            password.classList.remove("is-invalid")
            password.classList.add("is-valid")
            
        }
        
    })
    window.addEventListener("mousemove", e => {
        if(email.classList.contains("is-valid") & ulice.classList.contains("is-valid") & obec.classList.contains("is-valid") & NUM.classList.contains("is-valid") & PSC.classList.contains("is-valid") & password.classList.contains("is-valid"))
        {
            submit.disabled = false;
        }
        else{
            submit.disabled = true;
        }
    })
    


    email.addEventListener("blur", e => {
        if (validateEmail(email)){

            email.classList.remove('is-invalid')

            email.classList.add('is-valid')

        }

        else{

            email.classList.remove('is-valid')

            email.classList.add('is-invalid')

        }

        })
        function validateEmail(email)

        {
            var result = email.value.includes("@");
            return result;
        }

}


window.addEventListener("DOMContentLoaded", init)

