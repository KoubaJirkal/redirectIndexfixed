
function redirectPage(){
    var jmeno = document.getElementById("street").value;
    window.location.href= ("./index.html?jmeno="+jmeno);
}
function redirectIndex(jmeno){
    alert("idk")
    window.location.href= ("./index.html?jmeno=");
}
